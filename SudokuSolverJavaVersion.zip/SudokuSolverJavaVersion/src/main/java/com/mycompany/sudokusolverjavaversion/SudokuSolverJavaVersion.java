/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */
package com.mycompany.sudokusolverjavaversion;

import static com.mycompany.sudokusolverjavaversion.sudoku.printPuzzle;
import static com.mycompany.sudokusolverjavaversion.sudoku.solveSudoku;

/**
 *
 * @author tudea
 */

/*
Write a program to solve a Sudoku puzzle by filling the empty cells.

A sudoku solution must satisfy all of the following rules:

    Each of the digits 1-9 must occur exactly once in each row.
    Each of the digits 1-9 must occur exactly once in each column.
    Each of the digits 1-9 must occur exactly once in each of the 9 3x3 sub-boxes of the grid.

The '.' character indicates empty cells.
 */

public class SudokuSolverJavaVersion {

    public static void main(String[] args) {

        char[][] puzzle = {
            {'5', '3', '.', '.', '7', '.', '.', '.', '.'},
            {'6', '.', '.', '1', '9', '5', '.', '.', '.'},
            {'.', '9', '8', '.', '.', '.', '.', '6', '.'},
            {'8', '.', '.', '.', '6', '.', '.', '.', '3'},
            {'4', '.', '.', '8', '.', '3', '.', '.', '1'},
            {'7', '.', '.', '.', '2', '.', '.', '.', '6'},
            {'.', '6', '.', '.', '.', '.', '2', '8', '.'},
            {'.', '.', '.', '4', '1', '9', '.', '.', '5'},
            {'.', '.', '.', '.', '8', '.', '.', '7', '9'}
        };

        System.out.println("Sudoku Puzzle:");
        printPuzzle(puzzle);
        
        // Solve the puzzle
        if (solveSudoku(puzzle)) {
            System.out.println("\nSolved Sudoku Puzzle:");
           printPuzzle(puzzle);
        } else {
            System.out.println("\nNo solution exists for the given Sudoku puzzle.");
        }
    }
}


class sudoku {

    static boolean solveSudoku(char[][] puzzle) {
        for (int row = 0; row < 9; row++) {
            for (int col = 0; col < 9; col++) {
                if (puzzle[row][col] == '.') {
                    for (char number = '1'; number <= '9'; number++) {
                        if (isItValid(puzzle, row, col, number))
                            {
                                puzzle[row][col] = number;
                                
                                //solve board recursively
                                if(solveSudoku(puzzle))
                                {
                                    return true;
                                }
                                 puzzle[row][col] = '.';

                        }
                    }
                    return false;
                }
            }
        }
        return true;
    }
    static boolean isItValid(char [][] puzzle, int row, int col, char number)
    {
        //check row
        for(int i = 0;i < 9; i++)
        {
            if(puzzle.length == 9){
            if(puzzle[row][i] == number)
            {
                return false;
                
            }}
        }  
        
        //check column
        
        for(int i = 0;i < 9; i++)
        {
            if(puzzle[i].length == 9){
            if(puzzle[i][col] == number)
            {
                return false;
                
            }}
        }  
        
        int startRow = row - row % 3; //row of 3 x 3 box
        int startCol = col - col % 3; //col of 3 x 3 box
        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 3; j++) {
                if (puzzle[startRow + i][startCol + j] == number) {
                    return false; // Digit already exists in 3 x 3 box
                }
            }
    }
   return true;
}
  static void printPuzzle(char puzzle [][])
 {
     for (int i = 0; i < 9; i++) {
            for (int j = 0; j < 9; j++) {
                System.out.print(puzzle[i][j] + " ");
            }
            System.out.println();
        }
     
 }
}